from werkzeug.security import generate_password_hash, check_password_hash
from app import db, app
from datetime import datetime

class User(db.Model):
    __tablename__ = 'user'  # Explicitly set table name
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)  # Ensure this field is not NULL
    role = db.Column(db.String(20), default='user', nullable=False)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

class Request(db.Model):
    __tablename__ = 'request'
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    age = db.Column(db.String(50))
    gender = db.Column(db.String(50))
    time = db.Column(db.String(50))
    baseline = db.Column(db.String(50))
    num_hospitals = db.Column(db.String(50))
    status = db.Column(db.String(50), default='pending')
    result = db.Column(db.Text, nullable=True)
    question = db.Column(db.Text, nullable=True)  # Added question column
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'age': self.age,
            'gender': self.gender,
            'time': self.time,
            'baseline': self.baseline,
            'num_hospitals': self.num_hospitals,
            'status': self.status,
            'result': self.result,
            'question': self.question,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create all database tables
    app.run(debug=True)