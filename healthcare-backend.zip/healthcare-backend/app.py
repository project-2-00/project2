from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from functools import wraps
from flask_cors import CORS

app = Flask(__name__)
CORS(app, resources={
    r"/*": {
        "origins": [
            "http://localhost:3000",
            "https://fedhealth.vercel.app"
        ],
        "methods": ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

# Configure the app
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///healthcare.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_SECRET_KEY'] = 'your_jwt_secret'

# Initialize extensions
db = SQLAlchemy(app)
jwt = JWTManager(app)

# Import models after initializing db
from models.user import User, Request

# Decorator for role-based access
def role_required(role):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            current_user = User.query.filter_by(username=get_jwt_identity()).first()
            if not current_user or current_user.role != role:
                return jsonify({"message": "Access forbidden"}), 403
            return func(*args, **kwargs)
        return wrapper
    return decorator

# Routes
@app.route('/register', methods=['POST'])
def register():
    data = request.json
    if not data.get('username') or not data.get('password'):
        return jsonify({"message": "Missing username or password"}), 400

    if User.query.filter_by(username=data['username']).first():
        return jsonify({"message": "User already exists"}), 400

    user = User(username=data['username'])
    user.set_password(data['password'])  # Ensure this line is present
    db.session.add(user)
    db.session.commit()
    return jsonify({"message": "User registered successfully"}), 201



@app.route('/login', methods=['POST'])
def login():
    data = request.json
    user = User.query.filter_by(username=data['username']).first()
    if not user or not user.check_password(data['password']):
        return jsonify({"message": "Invalid credentials"}), 401

    access_token = create_access_token(identity=data['username'])
    return jsonify({
        "access_token": access_token,
        "role": user.role
    }), 200


@app.route('/train', methods=['POST'])
@jwt_required()
def train():
    data = request.json
    # Mocked training logic
    return jsonify({"message": "Training started with data", "data": data}), 200


@app.route('/treatment-requests', methods=['POST'])
@jwt_required()
def submit_request():
    current_user = User.query.filter_by(username=get_jwt_identity()).first()
    data = request.json

    # Add validation for required fields
    required_fields = ['age', 'time', 'baseline', 'gender', 'question', 'num_hospitals']
    for field in required_fields:
        if field not in data:
            return jsonify({"message": f"Missing required field: {field}"}), 400

    if not data.get('num_hospitals'):
        return jsonify({"message": "Number of hospitals is required"}), 400

    new_request = Request(
        user_id=current_user.id,
        age=data['age'],
        time=data['time'],
        baseline=data['baseline'],
        gender=data['gender'],
        question=data['question'],
        num_hospitals=data['num_hospitals']  # Add this line to ensure it's set
    )
    db.session.add(new_request)
    db.session.commit()
    return jsonify({"message": "Request submitted successfully"}), 201


@app.route('/treatment-requests', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_all_requests():
    requests = Request.query.all()
    return jsonify([req.to_dict() for req in requests]), 200


@app.route('/treatment-requests/<int:request_id>', methods=['GET'])
@jwt_required()
def get_request(request_id):
    request = Request.query.get_or_404(request_id)
    return jsonify(request.to_dict()), 200
@app.route('/treatment-requests/<int:request_id>', methods=['PUT'])
@jwt_required()
@role_required('admin')
def process_request(request_id):
    data = request.json
    if not data:
        return jsonify({"message": "No data provided"}), 400
    
    if 'result' not in data:
        return jsonify({"message": "Result is required"}), 400

    treatment_request = Request.query.get_or_404(request_id)

    try:
        treatment_request.status = 'processed'
        treatment_request.result = data['result']

        # Convert string values to float
        baseline = float(treatment_request.baseline)
        time = float(treatment_request.time)
        arthritis_percentage = min(100, max(0, (baseline + time) * 10))

        db.session.commit()

        return jsonify({
            "message": "Request processed successfully",
            "arthritis_percentage": arthritis_percentage,
            "request_status": treatment_request.status,
            "request_result": treatment_request.result
        }), 200
    except ValueError:
        return jsonify({"message": "Invalid numeric values"}), 400


@app.route('/my-requests', methods=['GET'])
@jwt_required()
def get_my_requests():
    current_user = User.query.filter_by(username=get_jwt_identity()).first()
    if not current_user:
        return jsonify({"message": "User not found"}), 404

    # Filter requests where status is not pending
    requests = Request.query.filter_by(
        user_id=current_user.id
    ).filter(
        Request.status != 'pending'
    ).all()
    
    return jsonify([req.to_dict() for req in requests]), 200

@app.route('/api/verify-token', methods=['GET'])
@jwt_required()
def verify_token():
    try:
        current_user = get_jwt_identity()
        user = User.query.filter_by(username=current_user).first()
        if not user:
            return jsonify({"message": "User not found"}), 404
        return jsonify({
            "message": "Token is valid",
            "user": current_user,
            "role": user.role
        }), 200
    except Exception as e:
        return jsonify({"message": "Token verification failed"}), 401

@app.route('/users/<int:user_id>/treatment-results', methods=['GET'])
@jwt_required()
@role_required('admin')
def get_user_results(user_id):
    requests = Request.query.filter_by(user_id=user_id, status='processed').all()
    return jsonify([r.to_dict() for r in requests]), 200


@app.route('/')
def hello():
    return jsonify({"message": "Welcome to the Healthcare API!"}), 200
if __name__ == '__main__':
    with app.app_context():
        db.create_all()  # Create database tables
    app.run(debug=True)
