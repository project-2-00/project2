import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import SelectHospitalPage from './pages/SelectHospitalPage';
import SubmitRequestPage from './pages/SubmitRequestPage';
import Dashboard from './pages/dashboard';

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<SelectHospitalPage />} />
        <Route path="/select-hospital" element={<SelectHospitalPage />} />
        <Route path="/submit-request" element={<SubmitRequestPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path='dashboard' element={<Dashboard />} />  
      </Routes>
    </Router>
  );
};

export default App;