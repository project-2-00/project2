import React, { useState } from 'react';
import { Dialog, DialogBackdrop, DialogPanel, DialogTitle } from '@headlessui/react';
import { 
  CheckIcon, 
  ExclamationCircleIcon,
  UserIcon,
  ClockIcon,
  ChartBarIcon,
  UserGroupIcon,
  BuildingOfficeIcon,
  QuestionMarkCircleIcon,
  InformationCircleIcon
} from '@heroicons/react/24/outline';
import Header from '../components/Header';
import Footer from '../components/Footer';

const SubmitRequestPage = () => {
  const [formData, setFormData] = useState({
    age: '',
    time: '',
    baseline: '',
    gender: '',
    num_hospitals: '',
    question: '', // Add this field
  });
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [swollenJointsPercentage, setSwollenJointsPercentage] = useState<number | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setError(null);
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value.toString() }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError(null);
    
    const selectedRole = localStorage.getItem('userRole');
    const accessToken = localStorage.getItem('accessToken');

    if (!selectedRole) {
      setError('Please select a role to proceed.');
      setIsSubmitting(false);
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/treatment-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ ...formData, role: selectedRole }),
      });

      if (!response.ok) {
        throw new Error('Failed to submit the request. Please check your inputs.');
      }

      const data = await response.json();
      const percentage = parseFloat(((parseFloat(formData.baseline.toString()) / 100) * 80).toString());
      setSwollenJointsPercentage(percentage);
      setIsDialogOpen(true);
    } catch (error) {
      setError(error instanceof Error ? error.message : 'An unexpected error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: `
        linear-gradient(to bottom right, rgba(99, 102, 241, 0.1), rgba(59, 130, 246, 0.1)),
        radial-gradient(circle at 1px 1px, rgba(99, 102, 241, 0.1) 1px, transparent 0)
      `,
      backgroundSize: '100% 100%, 20px 20px',
    }}>
      <Header />
      <main className="flex-grow py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <div className="bg-white shadow-xl rounded-2xl overflow-hidden transform transition-all hover:shadow-2xl">
              {/* Form Header */}
              <div className="px-6 py-8 border-b border-gray-200 bg-gradient-to-r from-indigo-500/10 to-blue-500/10">
                <div className="flex items-center justify-center mb-4">
                  <svg className="w-12 h-12 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM17 13H13V17H11V13H7V11H11V7H13V11H17V13Z" />
                  </svg>
                </div>
                <h2 className="text-2xl font-bold text-gray-900 text-center">Submit Treatment Request</h2>
                {error && (
                  <div className="mt-4 p-4 bg-red-50 rounded-md">
                    <div className="flex">
                      <ExclamationCircleIcon className="h-5 w-5 text-red-400" />
                      <p className="ml-3 text-sm text-red-700">{error}</p>
                    </div>
                  </div>
                )}
              </div>
              
              {/* Form Fields */}
              <form onSubmit={handleSubmit} className="px-6 py-8 space-y-8">
                <div className="grid grid-cols-1 gap-y-8 sm:grid-cols-2 sm:gap-x-8">
                  {/* Age Field */}
                  <div className="space-y-2">
                    <label className="flex items-center text-sm font-semibold text-gray-900">
                      <UserIcon className="w-4 h-4 mr-2 text-indigo-600" />
                      Age
                    </label>
                    <input
                      type="number"
                      name="age"
                      value={formData.age}
                      onChange={handleInputChange}
                      className="block w-full px-4 py-3 text-gray-900 border border-gray-300 rounded-lg shadow-sm 
                        focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                        hover:border-indigo-300 transition-all duration-200
                        placeholder:text-gray-400 text-base"
                      placeholder="Enter your age"
                      required
                    />
                  </div>

                  {/* Time Field */}
                  <div className="space-y-2">
                    <label className="flex items-center text-sm font-semibold text-gray-900">
                      <ClockIcon className="w-4 h-4 mr-2 text-indigo-600" />
                      Time (Weeks)
                    </label>
                    <input
                      type="number"
                      name="time"
                      value={formData.time}
                      onChange={handleInputChange}
                      className="block w-full px-4 py-3 text-gray-900 border border-gray-300 rounded-lg shadow-sm 
                        focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                        hover:border-indigo-300 transition-all duration-200
                        placeholder:text-gray-400 text-base"
                      placeholder="Enter time period"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="baseline" className="block text-sm font-semibold text-gray-900">
                      Baseline (Swollen Joints)
                    </label>
                    <input
                      type="number"
                      id="baseline"
                      name="baseline"
                      value={formData.baseline}
                      onChange={handleInputChange}
                      className="block w-full px-4 py-3 text-gray-900 border border-gray-300 rounded-lg shadow-sm 
                        focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                        hover:border-indigo-300 transition-colors duration-200
                        placeholder:text-gray-400 text-base"
                      placeholder="Enter baseline value"
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="gender" className="block text-sm font-semibold text-gray-900">
                      Gender
                    </label>
                    <select
                      id="gender"
                      name="gender"
                      value={formData.gender}
                      onChange={handleInputChange}
                      className="block w-full px-4 py-3 text-gray-900 border border-gray-300 rounded-lg shadow-sm 
                        focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                        hover:border-indigo-300 transition-colors duration-200
                        placeholder:text-gray-400 text-base"
                      required
                    >
                      <option value="">Select your gender</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="num_hospitals" className="block text-sm font-semibold text-gray-900">
                      Number of Hospitals
                    </label>
                    <input
                      type="number"
                      id="num_hospitals"
                      name="num_hospitals"
                      value={formData.num_hospitals}
                      onChange={handleInputChange}
                      className="block w-full px-4 py-3 text-gray-900 border border-gray-300 rounded-lg shadow-sm 
                        focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                        hover:border-indigo-300 transition-colors duration-200
                        placeholder:text-gray-400 text-base"
                      placeholder="Enter number of hospitals"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="flex items-center text-sm font-semibold text-gray-900">
                    <QuestionMarkCircleIcon className="w-4 h-4 mr-2 text-indigo-600" />
                    Your Question
                  </label>
                  <textarea
                    name="question"
                    value={formData.question}
                    onChange={handleInputChange}
                    rows={4}
                    className="block w-full px-4 py-3 text-gray-900 border border-gray-300 rounded-lg shadow-sm 
                      focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500
                      hover:border-indigo-300 transition-all duration-200
                      placeholder:text-gray-400 text-base resize-none"
                    placeholder="Enter your question here..."
                    required
                  />
                  <p className="mt-1 text-sm text-gray-500 flex items-center">
                    <InformationCircleIcon className="w-4 h-4 mr-1" />
                    Please provide any specific questions or concerns you'd like to address.
                  </p>
                </div>

                <div className="pt-8 border-t border-gray-200">
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className={`
                        inline-flex items-center px-6 py-3 text-base font-medium rounded-lg
                        ${isSubmitting 
                          ? 'bg-indigo-400 cursor-not-allowed' 
                          : 'bg-indigo-600 hover:bg-indigo-700 transform hover:scale-105'
                        }
                        text-white transition-all duration-200 shadow-lg hover:shadow-xl
                      `}
                    >
                      {isSubmitting ? (
                        <>
                          <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                          </svg>
                          Processing...
                        </>
                      ) : (
                        <>
                          <CheckIcon className="w-5 h-5 mr-2" />
                          Submit Request
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </main>

      <Dialog open={isDialogOpen} onClose={() => setIsDialogOpen(false)} className="relative z-10">
        <DialogBackdrop className="fixed inset-0 bg-black bg-opacity-50 transition-opacity" />
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
            <DialogPanel className="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-sm sm:p-6">
              <div>
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                  <CheckIcon className="h-6 w-6 text-green-600" aria-hidden="true" />
                </div>
                <div className="mt-3 text-center sm:mt-5">
                  <DialogTitle as="h3" className="text-lg font-medium leading-6 text-gray-900">
                    Request Submitted Successfully
                  </DialogTitle>
                  <div className="mt-4">
                    <p className="text-sm text-gray-500">
                      Your request has been submitted successfully. You will receive the results soon.
                    </p> 
                  </div>
                </div>
              </div>
              <div className="mt-5 sm:mt-6">
                <button
                  type="button"
                  onClick={() => setIsDialogOpen(false)}
                  className="inline-flex w-full justify-center rounded-lg bg-indigo-600 px-4 py-3 text-base font-semibold text-white shadow-sm hover:bg-indigo-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 transition-colors duration-200"
                >
                  Close
                </button>
              </div>
            </DialogPanel>
          </div>
        </div>
      </Dialog>

      <Footer />
    </div>
  );
};

export default SubmitRequestPage;