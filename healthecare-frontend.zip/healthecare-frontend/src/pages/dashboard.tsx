'use client';

import React, { useState, useEffect } from 'react';
import Chart from '../components/Chart';
import BoxPlot from '../components/BoxPlot';
import { UserIcon, HomeIcon, CheckIcon, ExclamationCircleIcon } from '@heroicons/react/24/outline';

// Add type definition for treatment requests
interface TreatmentRequest {
  id: number;
  patient_name?: string;
  age: number;
  gender: string;
  time: number;
  baseline: number;
  status: 'pending' | 'processed';
  question?: string;
  result?: string;
}

const Dashboard = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [userRole, setUserRole] = useState<string | null>(null);
  const [treatmentRequests, setTreatmentRequests] = useState<TreatmentRequest[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showTrainingOverlay, setShowTrainingOverlay] = useState(false);
  const [selectedRequestId, setSelectedRequestId] = useState<number | null>(null);
  const [hospital1Trained, setHospital1Trained] = useState(false);
  const [hospital2Trained, setHospital2Trained] = useState(false);
  const [isSendingResult, setIsSendingResult] = useState(false);
  const [arthritisPercentage, setArthritisPercentage] = useState<number | null>(null);
  const [toast, setToast] = useState<{
    show: boolean;
    message: string;
    type: 'success' | 'error';
  } | null>(null);

  const onProcess = () => {
    fetchTreatmentRequests();
  };

  // Add toast helper function
  const showToast = (message: string, type: 'success' | 'error') => {
    setToast({ show: true, message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Add error boundary
  const handleProcessRequest = async (requestId: number) => {
    try {
      setSelectedRequestId(requestId);
      setShowTrainingOverlay(true);
    } catch (error) {
      showToast('Failed to process request. Please try again.', 'error');
    }
  };

  const handleTrainHospital = async (hospitalId: number) => {
    try {
      // Simulate training
      await new Promise(resolve => setTimeout(resolve, 2000));
      if (hospitalId === 1) setHospital1Trained(true);
      if (hospitalId === 2) setHospital2Trained(true);
      
      showToast(`Model trained successfully in Hospital ${hospitalId}`, 'success');
    } catch (error) {
      showToast(`Error training hospital ${hospitalId}`, 'error');
    }
  };

  const handleSendResult = async () => {
    if (!selectedRequestId) return;
    
    setIsSendingResult(true);
    try {
      // Find the request that's being processed
      const request = treatmentRequests.find(req => req.id === selectedRequestId);
      if (!request) throw new Error('Request not found');

      // Calculate arthritis percentage using the formula
      const baseline = parseFloat(request.baseline.toString());
      const time = parseFloat(request.time.toString());
      const calculatedPercentage = Math.min(100, Math.max(0, (baseline + time) * 10));

      const response = await fetch(`http://localhost:5000/treatment-requests/${selectedRequestId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('accessToken')}`,
        },
        body: JSON.stringify({ 
          result: `Arthritis Risk: ${calculatedPercentage.toFixed(1)}%`
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to process request');
      }

      const data = await response.json();
      setArthritisPercentage(data.arthritis_percentage);
      showToast('Global model updated successfully!', 'success');
      
      await fetchTreatmentRequests();
      setShowTrainingOverlay(false);
      resetTrainingState();
      
    } catch (error) {
      showToast('Failed to process request. Please try again.', 'error');
    } finally {
      setIsSendingResult(false);
    }
  };

  const resetTrainingState = () => {
    setHospital1Trained(false);
    setHospital2Trained(false);
    setSelectedRequestId(null);
  };

  useEffect(() => {
    // Fetch user role from local storage
    const role = localStorage.getItem('role');
    setUserRole(role);

    // Fetch treatment requests if the user is an admin
    if (role === 'admin') {
      fetchTreatmentRequests();
    }
  }, []);

  // Add error handling for data parsing
  const fetchTreatmentRequests = async () => {
    const token = localStorage.getItem('accessToken');
    if (!token) return;

    setIsLoading(true);
    try {
      const response = await fetch('http://localhost:5000/treatment-requests', {
        method: 'GET',
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Failed to fetch treatment requests');
      }

      const data = await response.json();
      // Validate and transform data
      const validatedData: TreatmentRequest[] = data.map((item: any) => ({
        id: item.id,
        patient_name: item.patient_name || 'N/A',
        age: Number(item.age),
        gender: item.gender,
        time: Number(item.time),
        baseline: Number(item.baseline),
        status: item.status,
        question: item.question,
        result: item.result
      }));
      
      setTreatmentRequests(validatedData);
    } catch (error) {
      console.error('Error fetching treatment requests:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Arthritis-related metrics
  const totalPatients = 1200;
  const activePatients = 950;
  const inactivePatients = 250;
  const treatmentSuccessRate = '79%';

  // Arthritis-related data
  const genderDistribution = [
    { name: 'Male', value: 560 },
    { name: 'Female', value: 640 },
  ];

  const ageDistribution = [
    { name: '0-20', value: 120 },
    { name: '21-40', value: 350 },
    { name: '41-60', value: 470 },
    { name: '60+', value: 260 },
  ];

  const treatmentProgressOverTime = [
    { time: 'Week 1', value: 30 },
    { time: 'Week 2', value: 50 },
    { time: 'Week 3', value: 80 },
    { time: 'Week 4', value: 120 },
    { time: 'Week 5', value: 160 },
    { time: 'Week 6', value: 200 },
  ];

  const treatmentComparison = [
    { name: 'Placebo', value: 40 },
    { name: 'Prednisone', value: 85 },
  ];

  const swollenJointsOverTime = [
    { time: 'Week 1', joints: 12 },
    { time: 'Week 2', joints: 9 },
    { time: 'Week 3', joints: 6 },
    { time: 'Week 4', joints: 4 },
  ];

  const swollenJointsByAgeAndTreatment = [
    { Age_Group: '<30', Swollen_Joints: 4, Treatment: 'Placebo' },
    { Age_Group: '<30', Swollen_Joints: 5, Treatment: 'Prednisone' },
    { Age_Group: '30-50', Swollen_Joints: 3, Treatment: 'Placebo' },
    { Age_Group: '30-50', Swollen_Joints: 4, Treatment: 'Prednisone' },
    { Age_Group: '50-70', Swollen_Joints: 5, Treatment: 'Placebo' },
    { Age_Group: '50-70', Swollen_Joints: 3, Treatment: 'Prednisone' }
  ];

  const slideInStyles = `
    @keyframes slide-in-right {
      from {
        transform: translateX(100%);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
  `;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="flex"> {/* Remove duplicate bg-gray-50 class */}
        {/* Sidebar */}
        <aside className="hidden md:block md:w-64 bg-white shadow-lg p-6">
          <div className="flex flex-col space-y-6">
            {/* Back to Home button */}
            <a
              href="/"
              className="flex items-center text-gray-600 hover:text-blue-600 font-medium transition-all"
            >
              <HomeIcon className="w-5 h-5 mr-2" />
              <span>Back to Home</span>
            </a>

            <h2 className="text-xl font-bold text-blue-600">Arthritis Insights</h2>
            <ul className="space-y-4">
              <li>
                <a
                  href="#main-dashboard"
                  className="block text-gray-600 hover:text-blue-600 font-medium transition-all"
                >
                  Main Dashboard
                </a>
              </li>
              
              {userRole === 'admin' && (
                <li>
                  <a
                    href="#treatment-requests"
                    className="block text-gray-600 hover:text-blue-600 font-medium transition-all"
                  >
                    Treatment Requests
                  </a>
                </li>
              )}
            </ul>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Header */}
          <div className="flex justify-between items-center mb-6">
            <button
              className="text-gray-500 focus:outline-none md:hidden"
              onClick={() => setSidebarOpen(!isSidebarOpen)}
            >
              <svg
                className="w-6 h-6"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth="2"
                  d="M4 6h16M4 12h16m-7 6h7"
                ></path>
              </svg>
            </button>
            <h1 className="text-2xl font-extrabold text-gray-800">Main Dashboard</h1>
          </div>

          {/* KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-6">
            <div className="bg-gradient-to-br from-blue-500 to-blue-400 p-4 rounded-lg shadow-md text-center text-white">
              <h3 className="text-lg font-semibold">Total Patients</h3>
              <p className="text-3xl font-bold">{totalPatients}</p>
            </div>
            <div className="bg-gradient-to-br from-green-500 to-green-400 p-4 rounded-lg shadow-md text-center text-white">
              <h3 className="text-lg font-semibold">Active Patients</h3>
              <p className="text-3xl font-bold">{activePatients}</p>
            </div>
            <div className="bg-gradient-to-br from-red-500 to-red-400 p-4 rounded-lg shadow-md text-center text-white">
              <h3 className="text-lg font-semibold">Inactive Patients</h3>
              <p className="text-3xl font-bold">{inactivePatients}</p>
            </div>
            <div className="bg-gradient-to-br from-yellow-500 to-yellow-400 p-4 rounded-lg shadow-md text-center text-white">
              <h3 className="text-lg font-semibold">Success Rate</h3>
              <p className="text-3xl font-bold">{treatmentSuccessRate}</p>
            </div>
          </div>

          {/* Charts Section */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Chart
              data={genderDistribution}
              type="bar"
              xAxisKey="name"
              yAxisKey="value"
              title="Gender Distribution"
              colors={['#FF5733', '#33B5E5']}
            />
            <Chart
              data={ageDistribution}
              type="bar"
              xAxisKey="name"
              yAxisKey="value"
              title="Age Distribution"
            />
            <Chart
              data={treatmentProgressOverTime}
              type="line"
              xAxisKey="time"
              yAxisKey="value"
              title="Treatment Progress Over Time"
            />
            <Chart
              data={treatmentComparison}
              type="bar"
              xAxisKey="name"
              yAxisKey="value"
              title="Treatment Effectiveness"
              colors={['#FF6347', '#4682B4']}
            />
            <Chart
              data={swollenJointsOverTime}
              type="line"
              xAxisKey="time"
              yAxisKey="joints"
              title="Swollen Joints Over Time"
            />
            <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300">
              <BoxPlot
                data={swollenJointsByAgeAndTreatment}
                title="Swollen Joints Analysis"
              />
            </div>
          </div>

          {/* Enhanced Treatment Requests Table */}
          {userRole === 'admin' && (
            <div id="treatment-requests" className="mt-10">
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-xl font-bold text-gray-900">Treatment Requests</h2>
                <button
                  onClick={onProcess}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-500 transition-colors"
                >
                  Refresh
                </button>
              </div>

              {isLoading ? (
                <div className="flex justify-center items-center h-48 bg-white rounded-lg shadow">
                  <div className="flex flex-col items-center">
                    <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-indigo-600"></div>
                    <p className="mt-4 text-sm text-gray-500">Loading requests...</p>
                  </div>
                </div>
              ) : (
                <div className="bg-white rounded-lg shadow overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Patient
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Age/Gender
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Time/Baseline
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Question
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Actions
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {treatmentRequests.map((request) => (
                          <tr 
                            key={request.id}
                            className="hover:bg-gray-50 transition-colors duration-150"
                          >
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="flex items-center">
                                <div className="h-10 w-10 flex-shrink-0">
                                  <div className="h-full w-full rounded-full bg-indigo-100 flex items-center justify-center">
                                    <UserIcon className="h-5 w-5 text-indigo-600" />
                                  </div>
                                </div>
                                <div className="ml-4">
                                  <div className="text-sm font-medium text-gray-900">
                                    {request.patient_name || 'N/A'}
                                  </div>
                                  <div className="text-sm text-gray-500">
                                    ID: {request.id}
                                  </div>
                                </div>
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{request.age} years</div>
                              <div className="text-sm text-gray-500">{request.gender}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm text-gray-900">{request.time} weeks</div>
                              <div className="text-sm text-gray-500">Baseline: {request.baseline}</div>
                            </td>
                            <td className="px-6 py-4">
                              <div className="text-sm text-gray-900 max-w-xs truncate">
                                {request.question}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                                ${request.status === 'processed' 
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-yellow-100 text-yellow-800'
                                }`}
                              >
                                {request.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              {request.status === 'pending' && (
                                <button
                                  onClick={() => handleProcessRequest(request.id)}
                                  disabled={isProcessing}
                                  className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                  {isProcessing ? (
                                    <>
                                      <svg className="animate-spin -ml-1 mr-2 h-4 w-4" fill="none" viewBox="0 0 24 24">
                                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                                      </svg>
                                      Processing...
                                    </>
                                  ) : (
                                    'Process'
                                  )}
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          )}
        </main>
      </div>
      {toast && (
        <div 
          className={`fixed top-4 right-4 px-4 py-2 rounded-lg shadow-lg flex items-center z-[1000] ${
            toast.type === 'success' ? 'bg-green-500' : 'bg-red-500'
          }`}
          style={{ 
            animation: 'slide-in-right 0.3s ease-out'
          }}
        >
          {toast.type === 'success' ? (
            <CheckIcon className="w-5 h-5 mr-2 text-white" />
          ) : (
            <ExclamationCircleIcon className="w-5 h-5 mr-2 text-white" />
          )}
          <span className="text-white">{toast.message}</span>
        </div>
      )}
      {showTrainingOverlay && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-2xl w-full mx-4">
            <h3 className="text-xl font-bold mb-4">Train Models</h3>
            
            <div className="space-y-6">
              {/* Hospital 1 Section */}
              <div className="p-4 border rounded-lg">
                <h4 className="font-semibold mb-2">Hospital 1</h4>
                <button
                  onClick={() => handleTrainHospital(1)}
                  disabled={hospital1Trained}
                  className={`w-full py-2 px-4 rounded-md ${
                    hospital1Trained 
                      ? 'bg-green-500 text-white'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  {hospital1Trained ? 'Trained ✓' : 'Train Model'}
                </button>
              </div>

              {/* Hospital 2 Section */}
              <div className="p-4 border rounded-lg">
                <h4 className="font-semibold mb-2">Hospital 2</h4>
                <button
                  onClick={() => handleTrainHospital(2)}
                  disabled={hospital2Trained}
                  className={`w-full py-2 px-4 rounded-md ${
                    hospital2Trained 
                      ? 'bg-green-500 text-white'
                      : 'bg-indigo-600 hover:bg-indigo-500 text-white'
                  }`}
                >
                  {hospital2Trained ? 'Trained ✓' : 'Train Model'}
                </button>
              </div>

              <div className="flex justify-end space-x-4 mt-6">
                <button
                  onClick={() => {
                    setShowTrainingOverlay(false);
                    resetTrainingState();
                  }}
                  className="px-4 py-2 text-gray-600 hover:text-gray-800"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSendResult}
                  disabled={!hospital1Trained || !hospital2Trained || isSendingResult}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSendingResult ? 'Sending...' : 'Send Result'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      <style>{slideInStyles}</style>
    </div>
  );
};

export default Dashboard;
