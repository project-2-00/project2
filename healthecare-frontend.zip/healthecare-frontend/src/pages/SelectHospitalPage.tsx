import React from 'react';
import { useNavigate } from 'react-router-dom';
import Footer from '../components/Footer';

const SelectHospitalPage = () => {
  const navigate = useNavigate();

  const handleSelectRole = (role: string) => {
    localStorage.setItem('userRole', role);
    navigate('/login');
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      background: `
        linear-gradient(to bottom right, rgba(99, 102, 241, 0.1), rgba(59, 130, 246, 0.1)),
        radial-gradient(circle at 1px 1px, rgba(99, 102, 241, 0.1) 1px, transparent 0)
      `,
      backgroundSize: '100% 100%, 20px 20px',
    }}>
      {/* Main content */}
      <main style={{ flex: '1 0 auto', padding: '3rem 0' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 
              style={{
                fontSize: '2.5rem',
                fontWeight: 'bold',
                color: '#1F2937',
                marginBottom: '1rem'
              }}
            >
              FedHealth Platform
            </h1>
            <p style={{
              fontSize: '1.125rem',
              color: '#4B5563',
              maxWidth: '36rem',
              margin: '0 auto'
            }}>
              Select your role to participate in our federated learning healthcare system
            </p>
          </div>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
            gap: '2rem',
            maxWidth: '48rem',
            margin: '0 auto'
          }}>
            {/* Third Party Card */}
            <button
              onClick={() => handleSelectRole('Third Party')}
              style={{
                position: 'relative',
                padding: '2rem',
                background: 'white',
                borderRadius: '1rem',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                border: '1px solid rgba(229, 231, 235, 1)',
                textAlign: 'left',
                transition: 'all 0.3s ease',
                cursor: 'pointer',
                overflow: 'hidden',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.transform = 'scale(1.02)';
                e.currentTarget.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.1)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
              }}
            >
              <div style={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '8rem',
                height: '8rem',
                background: 'rgba(99, 102, 241, 0.1)',
                borderBottomLeftRadius: '100%'
              }} />
              <svg 
                style={{ width: '3rem', height: '3rem', color: '#4F46E5', marginBottom: '1rem' }}
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z" />
              </svg>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', color: '#1F2937', marginBottom: '0.5rem' }}>
                Third Party
              </h3>
              <p style={{ color: '#6B7280', marginBottom: '1rem', fontSize: '0.875rem' }}>
                Submit and analyze medical data using our secure federated learning system
              </p>
            </button>

            {/* Mediator Card */}
            <button
              onClick={() => handleSelectRole('Mediator')}
              style={{
                position: 'relative',
                padding: '2rem',
                background: 'white',
                borderRadius: '1rem',
                boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
                border: '1px solid rgba(229, 231, 235, 1)',
                textAlign: 'left',
                transition: 'all 0.3s ease',
                cursor: 'pointer',
                overflow: 'hidden',
              }}
              onMouseEnter={e => {
                e.currentTarget.style.transform = 'scale(1.02)';
                e.currentTarget.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.1)';
              }}
              onMouseLeave={e => {
                e.currentTarget.style.transform = 'scale(1)';
                e.currentTarget.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1)';
              }}
            >
              <div style={{
                position: 'absolute',
                top: 0,
                right: 0,
                width: '8rem',
                height: '8rem',
                background: 'rgba(59, 130, 246, 0.1)',
                borderBottomLeftRadius: '100%'
              }} />
              <svg 
                style={{ width: '3rem', height: '3rem', color: '#2563EB', marginBottom: '1rem' }}
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
              <h3 style={{ fontSize: '1.25rem', fontWeight: 'bold', color: '#1F2937', marginBottom: '0.5rem' }}>
                Mediator
              </h3>
              <p style={{ color: '#6B7280', marginBottom: '1rem', fontSize: '0.875rem' }}>
                Facilitate secure model training across healthcare institutions
              </p>
            </button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer style={{ flexShrink: 0 }}>
        <Footer />
      </footer>
    </div>
  );
};

export default SelectHospitalPage;