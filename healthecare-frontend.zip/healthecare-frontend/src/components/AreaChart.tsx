'use client';

import React from 'react';
import {
  AreaChart as ReAreaChart,
  Area,
  CartesianGrid,
  Tooltip,
  XAxis,
  YAxis,
  ResponsiveContainer,
} from 'recharts';

interface AreaChartProps {
  data: any[];
  index: string;
  categories: string[];
  valueFormatter: (value: number) => string;
  onValueChange?: (value: any) => void;
  className?: string;
}

export const AreaChart: React.FC<AreaChartProps> = ({
  data,
  index,
  categories,
  valueFormatter,
  onValueChange,
  className,
}) => {
  return (
    <div className={className}>
      <ResponsiveContainer width="100%" height="100%">
        <ReAreaChart data={data}>
          <defs>
            {categories.map((category, idx) => (
              <linearGradient
                id={`color${category}`}
                key={idx}
                x1="0"
                y1="0"
                x2="0"
                y2="1"
              >
                <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.8} />
                <stop offset="95%" stopColor="#4F46E5" stopOpacity={0} />
              </linearGradient>
            ))}
          </defs>
          <XAxis dataKey={index} />
          <YAxis />
          <Tooltip
            formatter={(value: number) => valueFormatter(value)}
            contentStyle={{ fontSize: '12px' }}
          />
          <CartesianGrid strokeDasharray="3 3" />
          {categories.map((category, idx) => (
            <Area
              key={idx}
              type="monotone"
              dataKey={category}
              stroke="#4F46E5"
              fillOpacity={1}
              fill={`url(#color${category})`}
            />
          ))}
        </ReAreaChart>
      </ResponsiveContainer>
    </div>
  );
};
