import React from 'react';
import Plot from 'react-plotly.js';

interface BoxPlotProps {
  data: Array<{ Age_Group: string; Swollen_Joints: number; Treatment: string }>;
  title: string;
}

const BoxPlot: React.FC<BoxPlotProps> = ({ data, title }) => {
  // Extract data for Placebo and Prednisone
  const placeboData = data
    .filter((item) => item.Treatment === 'Placebo')
    .map((item) => ({ x: item.Age_Group, y: item.Swollen_Joints }));

  const prednisoneData = data
    .filter((item) => item.Treatment === 'Prednisone')
    .map((item) => ({ x: item.Age_Group, y: item.Swollen_Joints }));

  return (
    <div className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl px-6 py-8 mb-6">
      <h3 className="text-lg font-bold text-center mb-4">{title}</h3>
      <Plot
        data={[
          {
            type: 'box',
            name: 'Placebo',
            x: placeboData.map((item) => item.x),
            y: placeboData.map((item) => item.y),
            marker: { color: '#33B5E5' }, // Blue color for Placebo
          },
          {
            type: 'box',
            name: 'Prednisone',
            x: prednisoneData.map((item) => item.x),
            y: prednisoneData.map((item) => item.y),
            marker: { color: '#FF6347' }, // Tomato color for Prednisone
          },
        ]}
        layout={{
          title: { text: title, font: { size: 16 } },
          xaxis: { title: 'Age Group' },
          yaxis: { title: 'Number of Swollen Joints' },
          boxmode: 'group', // Group the boxes side-by-side
        }}
        style={{ width: '100%', height: '400px' }}
      />
    </div>
  );
};

export default BoxPlot;
