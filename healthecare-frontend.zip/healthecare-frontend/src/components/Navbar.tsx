const Navbar = () => {
    return (
      <nav className="bg-indigo-600 p-4 text-white">
        <div className="container mx-auto flex justify-between">
          <h1 className="text-lg font-bold">HR Dashboard</h1>
          <div>
            <a href="/" className="px-4 hover:underline">
              Form
            </a>
            <a href="/dashboard" className="px-4 hover:underline">
              Dashboard
            </a>
          </div>
        </div>
      </nav>
    );
  };
  
  export default Navbar;
  