import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer style={{
      background: `linear-gradient(to right, 
        rgba(99, 102, 241, 0.9), 
        rgba(59, 130, 246, 0.9)
      )`,
      color: 'white',
      position: 'relative',
      overflow: 'hidden',
      borderTop: '1px solid rgba(99, 102, 241, 0.1)'
    }}>
      {/* Decorative pattern overlay */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: `
          radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.05) 1px, transparent 0)
        `,
        backgroundSize: '20px 20px',
        pointerEvents: 'none'
      }} />

      <div style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: '2rem 1rem',
        position: 'relative',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: '1rem'
      }}>
        <div style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.5rem',
          marginBottom: '1rem'
        }}>
          {/* Medical cross icon */}
          <svg 
            style={{ width: '2rem', height: '2rem' }}
            viewBox="0 0 24 24" 
            fill="currentColor"
          >
            <path d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM17 13H13V17H11V13H7V11H11V7H13V11H17V13Z" />
          </svg>
          <span style={{ 
            fontSize: '1.5rem', 
            fontWeight: 'bold',
            background: 'linear-gradient(to right, rgb(199, 210, 254), rgb(254, 202, 202))',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}>
            FedHealth
          </span>
        </div>

        <div style={{
          display: 'flex',
          gap: '2rem',
          marginBottom: '1rem'
        }}>
          <a href="#" style={{ 
            color: 'rgba(255, 255, 255, 0.8)',
            textDecoration: 'none',
            fontSize: '0.875rem',
            transition: 'color 0.2s'
          }} onMouseOver={e => e.currentTarget.style.color = 'white'}>
            Privacy Policy
          </a>
          <a href="#" style={{ 
            color: 'rgba(255, 255, 255, 0.8)',
            textDecoration: 'none',
            fontSize: '0.875rem',
            transition: 'color 0.2s'
          }} onMouseOver={e => e.currentTarget.style.color = 'white'}>
            Terms of Service
          </a>
          <a href="#" style={{ 
            color: 'rgba(255, 255, 255, 0.8)',
            textDecoration: 'none',
            fontSize: '0.875rem',
            transition: 'color 0.2s'
          }} onMouseOver={e => e.currentTarget.style.color = 'white'}>
            Contact Us
          </a>
        </div>

        <p style={{
          fontSize: '0.875rem',
          color: 'rgba(255, 255, 255, 0.8)',
          textAlign: 'center'
        }}>
          &copy; 2024 FedHealth Platform. Advancing healthcare through secure federated learning.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
