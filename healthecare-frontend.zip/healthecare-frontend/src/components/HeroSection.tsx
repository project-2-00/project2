'use client';

import React, { useState, useEffect } from 'react';
import { Dialog, DialogBackdrop, DialogPanel, DialogTitle } from '@headlessui/react';
import { CheckIcon } from '@heroicons/react/24/outline';

const HeroSection = () => {
  const [formData, setFormData] = useState<{
    age: string | number;
    time: string | number;
    baseline: string | number;
    gender: string;
    num_hospitals: string | number;
  }>({
    age: '',
    time: '',
    baseline: '',
    gender: '',
    num_hospitals: '',
  });

  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [swollenJointsPercentage, setSwollenJointsPercentage] = useState<number | null>(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentStep, setCurrentStep] = useState(1);
  const [selectedHospital, setSelectedHospital] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<string | null>(null);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value.toString() }));
  };

  const handleLogin = async (username: string, password: string) => {
    try {
      const response = await fetch('http://localhost:5000/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      if (!response.ok) {
        alert('Invalid credentials');
        return;
      }

      const data = await response.json();
      setAccessToken(data.access_token);
      localStorage.setItem('accessToken', data.access_token);
      localStorage.setItem('role', data.role);
      setUserRole(data.role);
      setIsLoggedIn(true);

      if (data.role === 'user') {
        setCurrentStep(2); // Move to step 2 if role is user
      } else {
        setCurrentStep(3); // Skip to step 3 if role is not user
      }
    } catch (error) {
      console.error('Error logging in:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!selectedHospital && userRole === 'user') {
      alert('Please select a hospital to proceed.');
      return;
    }

    try {
      const response = await fetch('http://localhost:5000/treatment-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ ...formData, hospital: selectedHospital }),
      });

      if (!response.ok) {
        alert('Failed to submit the request. Please check your inputs.');
        return;
      }

      const data = await response.json();
      const percentage = parseFloat(((parseFloat(formData.baseline.toString()) / 100) * 80).toString());
      setSwollenJointsPercentage(percentage);
      setIsDialogOpen(true);
    } catch (error) {
      console.error('Error submitting request:', error);
    }
  };

  const verifyToken = async (token: string) => {
    try {
      const response = await fetch('http://localhost:5000/verify-token', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
      });

      if (!response.ok) {
        throw new Error('Token is invalid');
      }

      const data = await response.json();
      setUserRole(data.role);
      return true;
    } catch (error) {
      console.error('Error verifying token:', error);
      return false;
    }
  };

  useEffect(() => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      verifyToken(token).then((isValid) => {
        if (isValid) {
          setAccessToken(token);
          setIsLoggedIn(true);
          if (userRole === 'user') {
            setCurrentStep(2); // Move to step 2 if role is user
          } else {
            setCurrentStep(3); // Skip to step 3 if role is not user
          }
        } else {
          localStorage.removeItem('accessToken');
        }
        setIsLoading(false);
      });
    } else {
      setIsLoading(false);
    }
  }, []);

  if (isLoading) {
    return <div>Loading...</div>;
  }

  if (currentStep === 1) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="max-w-sm w-full">
          <h2 className="text-center text-xl font-bold mb-4">Log in to Continue</h2>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              const username = (e.target as any).username.value;
              const password = (e.target as any).password.value;
              handleLogin(username, password);
            }}
          >
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">Username</label>
              <input
                name="username"
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            <div className="mb-4">
              <label className="block text-gray-700 text-sm font-bold mb-2">Password</label>
              <input
                name="password"
                type="password"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                required
              />
            </div>
            <button
              type="submit"
              className="bg-indigo-600 text-white py-2 px-4 rounded hover:bg-indigo-500"
            >
              Login
            </button>
          </form>
        </div>
      </div>
    );
  }

  if (currentStep === 2 && userRole === 'user') {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="max-w-sm w-full">
          <h2 className="text-center text-xl font-bold mb-4">Select a Hospital</h2>
          <div className="space-y-4">
            <button
              className="w-full py-2 px-4 bg-indigo-600 text-white rounded-md hover:bg-indigo-500"
              onClick={() => {
                setSelectedHospital('Hospital One');
                setCurrentStep(3); // Move to step 3 after selecting a hospital
              }}
            >
              Hospital One
            </button>
            <button
              className="w-full py-2 px-4 bg-indigo-600 text-white rounded-md hover:bg-indigo-500"
              onClick={() => {
                setSelectedHospital('Hospital Two');
                setCurrentStep(3); // Move to step 3 after selecting a hospital
              }}
            >
              Hospital Two
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (currentStep === 3) {
    return (
      <section className="bg-gray-100 py-12">
        <div className="container mx-auto px-6">
          <h2 className="text-2xl font-bold text-center mb-6">Submit Treatment Request</h2>
          <form
            onSubmit={handleSubmit}
            className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl px-6 py-8 max-w-3xl mx-auto"
          >
            <div className="grid grid-cols-1 gap-y-6 sm:grid-cols-2 sm:gap-x-8">
              <div>
                <label htmlFor="age" className="block text-sm font-medium leading-6 text-gray-900">
                  Age
                </label>
                <input
                  type="number"
                  id="age"
                  name="age"
                  value={formData.age}
                  onChange={handleInputChange}
                  className="mt-2 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"
                  placeholder="Enter age"
                  required
                />
              </div>
              <div>
                <label htmlFor="time" className="block text-sm font-medium leading-6 text-gray-900">
                  Time (Weeks)
                </label>
                <input
                  type="number"
                  id="time"
                  name="time"
                  value={formData.time}
                  onChange={handleInputChange}
                  className="mt-2 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"
                  placeholder="Enter time in weeks"
                  required
                />
              </div>
              <div>
                <label htmlFor="baseline" className="block text-sm font-medium leading-6 text-gray-900">
                  Baseline (Swollen Joints)
                </label>
                <input
                  type="number"
                  id="baseline"
                  name="baseline"
                  value={formData.baseline}
                  onChange={handleInputChange}
                  className="mt-2 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"
                  placeholder="Enter baseline value"
                  required
                />
              </div>
              <div>
                <label htmlFor="gender" className="block text-sm font-medium leading-6 text-gray-900">
                  Gender
                </label>
                <select
                  id="gender"
                  name="gender"
                  value={formData.gender}
                  onChange={handleInputChange}
                  className="mt-2 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
              <div>
                <label
                  htmlFor="num_hospitals"
                  className="block text-sm font-medium leading-6 text-gray-900"
                >
                  Number of Hospitals
                </label>
                <input
                  type="number"
                  id="num_hospitals"
                  name="num_hospitals"
                  value={formData.num_hospitals}
                  onChange={handleInputChange}
                  className="mt-2 block w-full rounded-md border-0 py-1.5 px-3 text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 focus:ring-2 focus:ring-inset focus:ring-indigo-600 sm:text-sm"
                  placeholder="Enter number of hospitals"
                  required
                />
              </div>
            </div>
            <div className="mt-6 flex items-center justify-end gap-x-6">
              <button
                type="submit"
                className="rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
              >
                Submit
              </button>
            </div>
          </form>
          <Dialog open={isDialogOpen} onClose={() => setIsDialogOpen(false)} className="relative z-10">
            <DialogBackdrop className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
            <div className="fixed inset-0 z-10 overflow-y-auto">
              <div className="flex min-h-full items-end justify-center p-4 text-center sm:items-center sm:p-0">
                <DialogPanel className="relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 sm:w-full sm:max-w-sm sm:p-6">
                  <div>
                    <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-green-100">
                      <CheckIcon aria-hidden="true" className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="mt-3 text-center sm:mt-5">
                      <DialogTitle as="h3" className="text-base font-semibold leading-6 text-gray-900">
                        Request Sent
                      </DialogTitle>
                      <div className="mt-2">
                        <p className="text-sm text-gray-500">
                          Your request has been submitted. You will get the result back soon.
                        </p>
                        <p className="text-xl font-bold text-indigo-600">
                        </p>
                      </div>
                    </div>
                  </div>
                  <div className="mt-5 sm:mt-6">
                    <button
                      type="button"
                      onClick={() => setIsDialogOpen(false)}
                      className="inline-flex w-full justify-center rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
                    >
                      Close
                    </button>
                  </div>
                </DialogPanel>
              </div>
            </div>
          </Dialog>
        </div>
      </section>
    );
  }

  return null;
};

export default HeroSection;