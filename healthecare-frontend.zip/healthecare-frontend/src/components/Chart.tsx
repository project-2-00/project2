import React from 'react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
  CartesianGrid,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface ChartProps {
  data: any[];
  type: 'bar' | 'line' | 'scatter';
  xAxisKey: string;
  yAxisKey: string;
  title: string;
  colors?: string[]; // Custom colors for the chart
  extraKey?: string; // Additional key for scatter charts
}

const Chart: React.FC<ChartProps> = ({ data, type, xAxisKey, yAxisKey, title, colors, extraKey }) => {
  return (
    <div className="bg-white shadow-sm ring-1 ring-gray-900/5 sm:rounded-xl px-6 py-8 mb-6">
      <h3 className="text-lg font-bold text-center mb-4">{title}</h3>
      <ResponsiveContainer width="100%" height={400}>
        {type === 'bar' ? (
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey={xAxisKey} />
            <YAxis />
            <Tooltip />
            {data.map((entry, index) => (
              <Bar
                key={index}
                dataKey={yAxisKey}
                fill={colors ? colors[index % colors.length] : '#4F46E5'} // Use custom colors
              />
            ))}
          </BarChart>
        ) : type === 'line' ? (
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey={xAxisKey} />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey={yAxisKey} stroke="#4F46E5" strokeWidth={2} />
          </LineChart>
        ) : (
          <ScatterChart>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey={xAxisKey} />
            <YAxis />
            <Tooltip />
            <Scatter
              data={data}
              fill="#4F46E5"
              dataKey={extraKey ? extraKey : yAxisKey} // Bubble color
            />
          </ScatterChart>
        )}
      </ResponsiveContainer>
    </div>
  );
};

export default Chart;
