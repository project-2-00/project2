'use client';

import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { BellIcon, UserCircleIcon } from '@heroicons/react/24/outline';
import NotificationDropdown from './NotificationDropdown';

export default function Header() {
  const [isAdmin, setIsAdmin] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const role = localStorage.getItem('role');
    if (role === 'admin') {
      setIsAdmin(true);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('role');
    navigate('/select-hospital');
  };

  return (
    <header style={{
      background: 'white',
      boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)',
      position: 'sticky',
      top: 0,
      zIndex: 50
    }}>
      <nav style={{
        maxWidth: '80rem',
        margin: '0 auto',
        padding: '1rem',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'
      }}>
        {/* Logo Section */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <svg 
            style={{ width: '2rem', height: '2rem', color: '#4F46E5' }}
            viewBox="0 0 24 24" 
            fill="none" 
            stroke="currentColor"
          >
            <path 
              strokeLinecap="round" 
              strokeLinejoin="round" 
              strokeWidth={2} 
              d="M19 3H5C3.9 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM17 13H13V17H11V13H7V11H11V7H13V11H17V13Z" 
            />
          </svg>
          <span style={{
            fontSize: '1.25rem',
            fontWeight: 'bold',
            background: 'linear-gradient(to right, #4F46E5, #2563EB)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent'
          }}>
            FedHealth
          </span>
        </div>

        {/* Navigation Links */}
        <div style={{ 
          display: 'flex', 
          gap: '2rem',
          alignItems: 'center'
        }}>
          
          {isAdmin && (
            <a 
              href="/treatment-requests"
              style={{
                color: '#4B5563',
                fontWeight: 500,
                fontSize: '0.875rem',
                transition: 'color 0.2s'
              }}
              onMouseOver={e => e.currentTarget.style.color = '#4F46E5'}
              onMouseLeave={e => e.currentTarget.style.color = '#4B5563'}
            >
              Requests
            </a>
          )}
        </div>

        {/* Right Section */}
        <div style={{ 
          display: 'flex', 
          alignItems: 'center',
          gap: '1rem'
        }}>
          <NotificationDropdown />
          
          {/* User Menu */}
          <div style={{ position: 'relative' }}>
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              style={{
                display: 'flex',
                alignItems: 'center',
                gap: '0.5rem',
                padding: '0.5rem',
                borderRadius: '0.375rem',
                transition: 'background-color 0.2s'
              }}
              onMouseOver={e => e.currentTarget.style.backgroundColor = '#F3F4F6'}
              onMouseLeave={e => e.currentTarget.style.backgroundColor = 'transparent'}
            >
              <UserCircleIcon style={{ width: '1.5rem', height: '1.5rem', color: '#4B5563' }} />
            </button>

            {showUserMenu && (
              <div style={{
                position: 'absolute',
                right: 0,
                marginTop: '0.5rem',
                width: '12rem',
                background: 'white',
                borderRadius: '0.5rem',
                boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                border: '1px solid #E5E7EB',
                overflow: 'hidden'
              }}>
                <div style={{ padding: '0.5rem' }}>
                  <button
                    onClick={handleLogout}
                    style={{
                      width: '100%',
                      textAlign: 'left',
                      padding: '0.5rem 1rem',
                      fontSize: '0.875rem',
                      color: '#4B5563',
                      borderRadius: '0.375rem',
                      transition: 'all 0.2s'
                    }}
                    onMouseOver={e => {
                      e.currentTarget.style.backgroundColor = '#F3F4F6';
                      e.currentTarget.style.color = '#1F2937';
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.backgroundColor = 'transparent';
                      e.currentTarget.style.color = '#4B5563';
                    }}
                  >
                    Sign out
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
}