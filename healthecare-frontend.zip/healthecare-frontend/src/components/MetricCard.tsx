import React from 'react';

interface MetricCardProps {
  title: string;
  value: string | number;
  trend: string;
  gradient: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, trend, gradient }) => (
  <div 
    className="rounded-xl p-6 shadow-lg transition-all duration-200 hover:-translate-y-1 hover:shadow-xl cursor-pointer"
    style={{ background: gradient }}
  >
    <div className="flex justify-between items-start">
      <div>
        <p className="text-white text-sm font-medium">{title}</p>
        <p className="text-white text-3xl font-bold mt-2">{value}</p>
      </div>
      <span className={`text-sm font-medium ${
        trend.startsWith('+') ? 'text-green-100' : 'text-red-100'
      }`}>
        {trend}
      </span>
    </div>
  </div>
);

export default MetricCard;