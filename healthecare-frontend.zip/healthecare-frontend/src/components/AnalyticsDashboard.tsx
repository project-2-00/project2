import React from 'react';
import Chart from './Chart';
import BoxPlot from './BoxPlot';
import MetricCard from './MetricCard';

const AnalyticsDashboard = () => {
  const metrics = {
    totalPatients: 1200,
    activePatients: 950,
    inactivePatients: 250,
    treatmentSuccessRate: '79%'
  };

  const chartData = {
    genderDistribution: [
      { name: 'Male', value: 560 },
      { name: 'Female', value: 640 },
    ],
    ageDistribution: [
      { name: '0-20', value: 120 },
      { name: '21-40', value: 350 },
      { name: '41-60', value: 470 },
      { name: '60+', value: 260 },
    ],
    treatmentProgressOverTime: [
      { time: 'Week 1', value: 30 },
      { time: 'Week 2', value: 50 },
      { time: 'Week 3', value: 80 },
      { time: 'Week 4', value: 120 },
      { time: 'Week 5', value: 160 },
      { time: 'Week 6', value: 200 },
    ],
    treatmentComparison: [
      { name: 'Placebo', value: 40 },
      { name: 'Prednisone', value: 85 },
    ],
    swollenJointsOverTime: [
      { time: 'Week 1', joints: 12 },
      { time: 'Week 2', joints: 9 },
      { time: 'Week 3', joints: 6 },
      { time: 'Week 4', joints: 4 },
    ],
    swollenJointsByAgeAndTreatment: [
      { Age_Group: '<30', Swollen_Joints: 4, Treatment: 'Placebo' },
      { Age_Group: '<30', Swollen_Joints: 5, Treatment: 'Prednisone' },
      { Age_Group: '30-50', Swollen_Joints: 3, Treatment: 'Placebo' },
      { Age_Group: '30-50', Swollen_Joints: 4, Treatment: 'Prednisone' },
      { Age_Group: '50-70', Swollen_Joints: 5, Treatment: 'Placebo' },
      { Age_Group: '50-70', Swollen_Joints: 3, Treatment: 'Prednisone' },
    ],
  };

  return (
    <div className="animate-fadeIn space-y-8">
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
        <MetricCard
          title="Total Patients"
          value={metrics.totalPatients}
          trend="+12%"
          gradient="linear-gradient(135deg, rgb(96, 165, 250), rgb(59, 130, 246))"
        />
        <MetricCard
          title="Active Patients"
          value={metrics.activePatients}
          trend="+5%"
          gradient="linear-gradient(135deg, rgb(74, 222, 128), rgb(34, 197, 94))"
        />
        <MetricCard
          title="Inactive Patients"
          value={metrics.inactivePatients}
          trend="-2%"
          gradient="linear-gradient(135deg, rgb(248, 113, 113), rgb(239, 68, 68))"
        />
        <MetricCard
          title="Success Rate"
          value={metrics.treatmentSuccessRate}
          trend="+8%"
          gradient="linear-gradient(135deg, rgb(250, 204, 21), rgb(234, 179, 8))"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <Chart
            data={chartData.genderDistribution}
            type="bar"
            xAxisKey="name"
            yAxisKey="value"
            title="Gender Distribution"
            colors={['#FF5733', '#33B5E5']}
          />
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <Chart
            data={chartData.ageDistribution}
            type="bar"
            xAxisKey="name"
            yAxisKey="value"
            title="Age Distribution"
          />
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <Chart
            data={chartData.treatmentProgressOverTime}
            type="line"
            xAxisKey="time"
            yAxisKey="value"
            title="Treatment Progress"
          />
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <Chart
            data={chartData.treatmentComparison}
            type="bar"
            xAxisKey="name"
            yAxisKey="value"
            title="Treatment Comparison"
            colors={['#FF6347', '#4682B4']}
          />
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <Chart
            data={chartData.swollenJointsOverTime}
            type="line"
            xAxisKey="time"
            yAxisKey="joints"
            title="Swollen Joints Trend"
          />
        </div>
        <div className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow">
          <BoxPlot
            data={chartData.swollenJointsByAgeAndTreatment}
            title="Swollen Joints Analysis"
          />
        </div>
      </div>
    </div>
  );
};

export default AnalyticsDashboard;